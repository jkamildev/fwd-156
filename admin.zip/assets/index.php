<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>SAU Computer Science Department</title>

    <link rel="stylesheet" href="style.css">
</head>

<body>

    <!-- Top bar -->
    <div class="top-bar">
        <div class="container top-content">
            <span>South Asian University · New Delhi</span>
            <a href="https://sau.int/">University Website ↗</a>
        </div>
    </div>

    <!-- Header -->
    <header>
        <div class="container header-content">
            <img
                src="./assets/South-Asian-University-logo-removebg-preview.png"
                alt="South Asian University logo"
                class="logo"
            >

            <div>
                <p class="university-name">SOUTH ASIAN UNIVERSITY</p>
                <h2>Department of Computer Science and Engineering</h2>
            </div>
        </div>
    </header>

    <!-- Navigation -->
    <nav aria-label="Main navigation">
        <div class="container navigation">
            <a href="#home">Home</a>
            <a href="#about">About</a>
            <a href="#programmes">Programmes</a>
            <a href="#research">Research</a>
            <a href="#notices">Notices</a>
            <a href="#resources">Resources</a>
            <a href="#contact">Contact</a>
        </div>
    </nav>

    <main>

        <!-- Welcome section -->
        <section class="hero" id="home">
            <div class="container hero-content">

                <div class="hero-text">
                    <p class="hero-label">LEARNING · COMPUTING · RESEARCH</p>

                    <h1>
                        Computer Science<br>
                        <span>and Engineering</span>
                    </h1>

                    <p>
                        Explore academic programmes, research areas and
                        departmental resources at South Asian University.
                    </p>

                    <div class="hero-buttons">
                        <a href="#programmes" class="button gold-button">
                            Explore Programmes
                        </a>

                        <a href="#research" class="button outline-button">
                            Discover Research
                        </a>
                    </div>
                </div>

                <aside class="quick-panel">
                    <h2>Quick Links</h2>
                    <p>Find the information you need.</p>

                    <a href="#programmes">Academic Programmes →</a>
                    <a href="#research">Research Areas →</a>
                    <a href="#resources">Faculty and Resources →</a>
                    <a href="#notices">Notice Board →</a>
                </aside>

            </div>
        </section>

        <!-- About -->
        <section class="section" id="about">
            <div class="container two-columns">

                <div class="main-column">
                    <p class="section-label">ABOUT THE DEPARTMENT</p>
                    <h2>A place to learn and explore computing.</h2>

                    <p>
                        The Department of Computer Science and Engineering
                        offers opportunities to explore computing through
                        academic study and research.
                    </p>

                    <p>
                        This homepage helps students and visitors find
                        programme information, research areas and
                        official departmental resources.
                    </p>

                    <a
                        href="https://sau.int/department-of-computer-science-and-engineering/"
                        class="text-link"
                    >
                        Visit the official department page →
                    </a>
                </div>

                <div class="about-panel">
                    <h3>Academic Learning</h3>
                    <p>Explore undergraduate and advanced study options.</p>

                    <h3>Research and Discovery</h3>
                    <p>Discover research interests and laboratory information.</p>

                    <h3>People and Community</h3>
                    <p>Find faculty profiles and departmental resources.</p>
                </div>

            </div>
        </section>

        <!-- Programmes -->
        <section class="section light-section" id="programmes">
            <div class="container">
                <div class="section-heading">
                    <p class="section-label">ACADEMIC PATHWAYS</p>
                    <h2>Explore Our Programmes</h2>
                    <p>Find your next step in computing.</p>
                </div>

                <div class="cards">

                    <article class="card">
                        <span class="card-label">UNDERGRADUATE</span>
                        <h3>Bachelor Programmes</h3>
                        <p>
                            Explore undergraduate study in computing
                            and related subjects.
                        </p>
                        <a href="https://sau.int/department-of-computer-science-and-engineering/">
                            Programme details →
                        </a>
                    </article>

                    <article class="card">
                        <span class="card-label">POSTGRADUATE</span>
                        <h3>Master Programmes</h3>
                        <p>
                            Explore advanced academic study and
                            specialised learning opportunities.
                        </p>
                        <a href="https://sau.int/department-of-computer-science-and-engineering/">
                            Programme details →
                        </a>
                    </article>

                    <article class="card">
                        <span class="card-label">DOCTORAL</span>
                        <h3>Doctoral Research</h3>
                        <p>
                            Explore PhD study and research opportunities
                            in computer science and engineering.
                        </p>
                        <a href="https://sau.int/department-of-computer-science-and-engineering/">
                            Programme details →
                        </a>
                    </article>

                </div>
            </div>
        </section>

        <!-- Research -->
        <section class="section" id="research">
            <div class="container">
                <div class="section-heading">
                    <p class="section-label">RESEARCH AND DISCOVERY</p>
                    <h2>Explore Research Areas</h2>
                </div>

                <div class="cards">

                    <article class="card research-card">
                        <h3>Artificial Intelligence</h3>
                        <p>
                            Explore learning algorithms and intelligent
                            computing systems.
                        </p>
                    </article>

                    <article class="card research-card">
                        <h3>Data Science</h3>
                        <p>
                            Explore data analysis and methods for
                            understanding patterns.
                        </p>
                    </article>

                    <article class="card research-card">
                        <h3>Networks and Systems</h3>
                        <p>
                            Explore communication networks and
                            distributed computing.
                        </p>
                    </article>

                </div>
            </div>
        </section>

        <!-- Notices and resources -->
        <section class="section light-section" id="notices">
            <div class="container two-columns">

                <div class="main-column">
                    <p class="section-label">DEPARTMENT UPDATES</p>
                    <h2>Notice Board</h2>
                    <p class="sample-note">
                        Sample announcements for this assignment.
                    </p>

                    <article class="notice">
                        <span class="card-label">SAMPLE · SEMINAR</span>
                        <h3>Department Research Seminar</h3>
                        <p>Add the confirmed topic, date and venue here.</p>
                    </article>

                    <article class="notice">
                        <span class="card-label">SAMPLE · ACADEMIC</span>
                        <h3>Course Information Update</h3>
                        <p>Add an approved course announcement here.</p>
                    </article>

                    <article class="notice">
                        <span class="card-label">SAMPLE · WORKSHOP</span>
                        <h3>Student Programming Workshop</h3>
                        <p>Add workshop details and participation instructions.</p>
                    </article>
                </div>

                <aside class="resources-panel" id="resources">
                    <h2>Department Resources</h2>
                    <p>
                        These links open the official department page
                        where you can find the relevant information.
                    </p>

                    <a href="https://sau.int/department-of-computer-science-and-engineering/">
                        Programmes and Course Structures ↗
                    </a>

                    <a href="https://sau.int/department-of-computer-science-and-engineering/">
                        Faculty Information ↗
                    </a>

                    <a href="https://sau.int/department-of-computer-science-and-engineering/">
                        Research Facilities ↗
                    </a>

                    <a href="https://sau.int/">University Website ↗</a>
                </aside>

            </div>
        </section>

        <!-- Contact -->
        <section class="section" id="contact">
            <div class="container">
                <div class="contact-box">
                    <h2>Want to Know More?</h2>

                    <p>
                        Visit the official department page for contact
                        details and further academic information.
                    </p>

                    <a
                        href="https://sau.int/department-of-computer-science-and-engineering/"
                        class="button blue-button"
                    >
                        Visit Department Page ↗
                    </a>
                </div>
            </div>
        </section>

    </main>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="footer-content">

                <div class="footer-brand">
                    <img
                        src="./assets/South-Asian-University-logo-removebg-preview.png  "
                        alt="South Asian University logo"
                        class="footer-logo"
                    >

                    <div>
                        <h3>South Asian University</h3>
                        <p>Computer Science and Engineering</p>
                    </div>
                </div>

                <div class="footer-links">
                    <a href="#about">About</a>
                    <a href="#programmes">Programmes</a>
                    <a href="#contact">Contact</a>
                </div>

            </div>

            <div class="footer-bottom">
                <span>SAU CSE Website · Student Assignment</span>
                <a href="#home">Back to top ↑</a>
            </div>
        </div>
    </footer>

</body>
</html>
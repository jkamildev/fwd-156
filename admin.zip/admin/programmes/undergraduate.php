<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Undergraduate | SAU Admin</title>
    <link rel="stylesheet" href="../assets/dashboard.css">
</head>
<body>
    <main class="container">
        <p class="brand">SOUTH ASIAN UNIVERSITY · ADMIN</p>
        <a class="back" href="index.php">← Programmes Dashboard</a>
        <h1>Undergraduate</h1>
        <p class="intro">Programmes / Undergraduate</p>
        <div class="notice">Form preview: saving is not connected to a database yet. These fields do not update the public website.</div>
        <form class="editor">
            <label for="field-0">Programme name</label>
            <input id="field-0" name="programme-name" type="text">
            <label for="field-1">Duration</label>
            <input id="field-1" name="duration" type="text">
            <label for="field-2">Eligibility</label>
            <input id="field-2" name="eligibility" type="text">
            <label for="field-3">Description</label>
            <textarea id="field-3" name="description" rows="5"></textarea>
            <label for="field-4">Course PDF path</label>
            <input id="field-4" name="course-pdf-path" type="text">
            <div class="actions">
                <button type="button" disabled>Save Changes — database required</button>
                <a href="index.php">Back to sections</a>
            </div>
        </form>
    </main>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Programmes | SAU Admin</title>
    <link rel="stylesheet" href="../assets/dashboard.css">
</head>
<body>
    <main class="container">
        <p class="brand">SOUTH ASIAN UNIVERSITY · ADMIN</p>
        <a class="back" href="../dashboard.php">← Main Dashboard</a>
        <h1>Manage Programmes Page</h1>
        <p class="intro">Which section would you like to change?</p>
        <div class="grid">
        <a class="dashboard-box red" href="undergraduate.php">
            <span class="icon" aria-hidden="true">✎</span>
            <h2>Undergraduate</h2>
            <p>Edit undergraduate</p>
            <span class="open">Open →</span>
        </a>
        <a class="dashboard-box blue" href="postgraduate.php">
            <span class="icon" aria-hidden="true">✎</span>
            <h2>Postgraduate</h2>
            <p>Edit postgraduate</p>
            <span class="open">Open →</span>
        </a>
        <a class="dashboard-box green" href="doctoral-research.php">
            <span class="icon" aria-hidden="true">✎</span>
            <h2>Doctoral Research</h2>
            <p>Edit doctoral research</p>
            <span class="open">Open →</span>
        </a>
        </div>
    </main>
</body>
</html>

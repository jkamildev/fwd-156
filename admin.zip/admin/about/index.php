<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage About | SAU Admin</title>
    <link rel="stylesheet" href="../assets/dashboard.css">
</head>
<body>
    <main class="container">
        <p class="brand">SOUTH ASIAN UNIVERSITY · ADMIN</p>
        <a class="back" href="../dashboard.php">← Main Dashboard</a>
        <h1>Manage About Page</h1>
        <p class="intro">Which section would you like to change?</p>
        <div class="grid">
        <a class="dashboard-box red" href="department-introduction.php">
            <span class="icon" aria-hidden="true">✎</span>
            <h2>Department Introduction</h2>
            <p>Edit department introduction</p>
            <span class="open">Open →</span>
        </a>
        <a class="dashboard-box blue" href="vision-and-mission.php">
            <span class="icon" aria-hidden="true">✎</span>
            <h2>Vision and Mission</h2>
            <p>Edit vision and mission</p>
            <span class="open">Open →</span>
        </a>
        <a class="dashboard-box green" href="heads-message.php">
            <span class="icon" aria-hidden="true">✎</span>
            <h2>Head’s Message</h2>
            <p>Edit head’s message</p>
            <span class="open">Open →</span>
        </a>
        <a class="dashboard-box dark" href="department-facilities.php">
            <span class="icon" aria-hidden="true">✎</span>
            <h2>Department Facilities</h2>
            <p>Edit department facilities</p>
            <span class="open">Open →</span>
        </a>
        </div>
    </main>
</body>
</html>

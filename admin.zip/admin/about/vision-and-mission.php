<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vision and Mission | SAU Admin</title>
    <link rel="stylesheet" href="../assets/dashboard.css">
</head>
<body>
    <main class="container">
        <p class="brand">SOUTH ASIAN UNIVERSITY · ADMIN</p>
        <a class="back" href="index.php">← About Dashboard</a>
        <h1>Vision and Mission</h1>
        <p class="intro">About / Vision and Mission</p>
        <div class="notice">Form preview: saving is not connected to a database yet. These fields do not update the public website.</div>
        <form class="editor">
            <label for="field-0">Vision</label>
            <textarea id="field-0" name="vision" rows="5"></textarea>
            <label for="field-1">Mission</label>
            <textarea id="field-1" name="mission" rows="5"></textarea>
            <div class="actions">
                <button type="button" disabled>Save Changes — database required</button>
                <a href="index.php">Back to sections</a>
            </div>
        </form>
    </main>
</body>
</html>

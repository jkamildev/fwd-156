<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Head’s Message | SAU Admin</title>
    <link rel="stylesheet" href="../assets/dashboard.css">
</head>
<body>
    <main class="container">
        <p class="brand">SOUTH ASIAN UNIVERSITY · ADMIN</p>
        <a class="back" href="index.php">← About Dashboard</a>
        <h1>Head’s Message</h1>
        <p class="intro">About / Head’s Message</p>
        <div class="notice">Form preview: saving is not connected to a database yet. These fields do not update the public website.</div>
        <form class="editor">
            <label for="field-0">Name</label>
            <input id="field-0" name="name" type="text">
            <label for="field-1">Position</label>
            <input id="field-1" name="position" type="text">
            <label for="field-2">Image path</label>
            <input id="field-2" name="image-path" type="text">
            <label for="field-3">Message</label>
            <textarea id="field-3" name="message" rows="5"></textarea>
            <div class="actions">
                <button type="button" disabled>Save Changes — database required</button>
                <a href="index.php">Back to sections</a>
            </div>
        </form>
    </main>
</body>
</html>

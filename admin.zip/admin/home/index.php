<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Home | SAU Admin</title>
    <link rel="stylesheet" href="../assets/dashboard.css">
</head>
<body>
    <main class="container">
        <p class="brand">SOUTH ASIAN UNIVERSITY · ADMIN</p>
        <a class="back" href="../dashboard.php">← Main Dashboard</a>
        <h1>Manage Home Page</h1>
        <p class="intro">Which section would you like to change?</p>
        <div class="grid">
        <a class="dashboard-box red" href="welcome-banner.php">
            <span class="icon" aria-hidden="true">✎</span>
            <h2>Welcome Banner</h2>
            <p>Edit welcome banner</p>
            <span class="open">Open →</span>
        </a>
        <a class="dashboard-box blue" href="welcome-text.php">
            <span class="icon" aria-hidden="true">✎</span>
            <h2>Welcome Text</h2>
            <p>Edit welcome text</p>
            <span class="open">Open →</span>
        </a>
        <a class="dashboard-box green" href="quick-links.php">
            <span class="icon" aria-hidden="true">✎</span>
            <h2>Quick Links</h2>
            <p>Edit quick links</p>
            <span class="open">Open →</span>
        </a>
        <a class="dashboard-box dark" href="featured-announcements.php">
            <span class="icon" aria-hidden="true">✎</span>
            <h2>Featured Announcements</h2>
            <p>Edit featured announcements</p>
            <span class="open">Open →</span>
        </a>
        </div>
    </main>
</body>
</html>

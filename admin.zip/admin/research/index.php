<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Research | SAU Admin</title>
    <link rel="stylesheet" href="../assets/dashboard.css">
</head>
<body>
    <main class="container">
        <p class="brand">SOUTH ASIAN UNIVERSITY · ADMIN</p>
        <a class="back" href="../dashboard.php">← Main Dashboard</a>
        <h1>Manage Research Page</h1>
        <p class="intro">Which section would you like to change?</p>
        <div class="grid">
        <a class="dashboard-box red" href="research-areas.php">
            <span class="icon" aria-hidden="true">✎</span>
            <h2>Research Areas</h2>
            <p>Edit research areas</p>
            <span class="open">Open →</span>
        </a>
        <a class="dashboard-box blue" href="research-projects.php">
            <span class="icon" aria-hidden="true">✎</span>
            <h2>Research Projects</h2>
            <p>Edit research projects</p>
            <span class="open">Open →</span>
        </a>
        <a class="dashboard-box green" href="research-laboratories.php">
            <span class="icon" aria-hidden="true">✎</span>
            <h2>Research Laboratories</h2>
            <p>Edit research laboratories</p>
            <span class="open">Open →</span>
        </a>
        </div>
    </main>
</body>
</html>

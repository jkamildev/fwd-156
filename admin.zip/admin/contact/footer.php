<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Footer | SAU Admin</title>
    <link rel="stylesheet" href="../assets/dashboard.css">
</head>
<body>
    <main class="container">
        <p class="brand">SOUTH ASIAN UNIVERSITY · ADMIN</p>
        <a class="back" href="index.php">← Contact Dashboard</a>
        <h1>Footer</h1>
        <p class="intro">Contact / Footer</p>
        <div class="notice">Form preview: saving is not connected to a database yet. These fields do not update the public website.</div>
        <form class="editor">
            <label for="field-0">Footer text</label>
            <textarea id="field-0" name="footer-text" rows="5"></textarea>
            <label for="field-1">University URL</label>
            <input id="field-1" name="university-url" type="text">
            <label for="field-2">Social link URL</label>
            <input id="field-2" name="social-link-url" type="text">
            <div class="actions">
                <button type="button" disabled>Save Changes — database required</button>
                <a href="index.php">Back to sections</a>
            </div>
        </form>
    </main>
</body>
</html>

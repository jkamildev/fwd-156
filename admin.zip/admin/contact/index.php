<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Contact | SAU Admin</title>
    <link rel="stylesheet" href="../assets/dashboard.css">
</head>
<body>
    <main class="container">
        <p class="brand">SOUTH ASIAN UNIVERSITY · ADMIN</p>
        <a class="back" href="../dashboard.php">← Main Dashboard</a>
        <h1>Manage Contact Page</h1>
        <p class="intro">Which section would you like to change?</p>
        <div class="grid">
        <a class="dashboard-box red" href="contact-details.php">
            <span class="icon" aria-hidden="true">✎</span>
            <h2>Contact Details</h2>
            <p>Edit contact details</p>
            <span class="open">Open →</span>
        </a>
        <a class="dashboard-box blue" href="location.php">
            <span class="icon" aria-hidden="true">✎</span>
            <h2>Location</h2>
            <p>Edit location</p>
            <span class="open">Open →</span>
        </a>
        <a class="dashboard-box green" href="footer.php">
            <span class="icon" aria-hidden="true">✎</span>
            <h2>Footer</h2>
            <p>Edit footer</p>
            <span class="open">Open →</span>
        </a>
        </div>
    </main>
</body>
</html>

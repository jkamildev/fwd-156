<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Notices | SAU Admin</title>
    <link rel="stylesheet" href="../assets/dashboard.css">
</head>
<body>
    <main class="container">
        <p class="brand">SOUTH ASIAN UNIVERSITY · ADMIN</p>
        <a class="back" href="../dashboard.php">← Main Dashboard</a>
        <h1>Manage Notices Page</h1>
        <p class="intro">Which section would you like to change?</p>
        <div class="grid">
        <a class="dashboard-box red" href="academic-notices.php">
            <span class="icon" aria-hidden="true">✎</span>
            <h2>Academic Notices</h2>
            <p>Edit academic notices</p>
            <span class="open">Open →</span>
        </a>
        <a class="dashboard-box blue" href="seminars.php">
            <span class="icon" aria-hidden="true">✎</span>
            <h2>Seminars</h2>
            <p>Edit seminars</p>
            <span class="open">Open →</span>
        </a>
        <a class="dashboard-box green" href="workshops.php">
            <span class="icon" aria-hidden="true">✎</span>
            <h2>Workshops</h2>
            <p>Edit workshops</p>
            <span class="open">Open →</span>
        </a>
        </div>
    </main>
</body>
</html>

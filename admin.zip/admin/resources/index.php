<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Resources | SAU Admin</title>
    <link rel="stylesheet" href="../assets/dashboard.css">
</head>
<body>
    <main class="container">
        <p class="brand">SOUTH ASIAN UNIVERSITY · ADMIN</p>
        <a class="back" href="../dashboard.php">← Main Dashboard</a>
        <h1>Manage Resources Page</h1>
        <p class="intro">Which section would you like to change?</p>
        <div class="grid">
        <a class="dashboard-box red" href="faculty-information.php">
            <span class="icon" aria-hidden="true">✎</span>
            <h2>Faculty Information</h2>
            <p>Edit faculty information</p>
            <span class="open">Open →</span>
        </a>
        <a class="dashboard-box blue" href="course-materials.php">
            <span class="icon" aria-hidden="true">✎</span>
            <h2>Course Materials</h2>
            <p>Edit course materials</p>
            <span class="open">Open →</span>
        </a>
        <a class="dashboard-box green" href="useful-links.php">
            <span class="icon" aria-hidden="true">✎</span>
            <h2>Useful Links</h2>
            <p>Edit useful links</p>
            <span class="open">Open →</span>
        </a>
        </div>
    </main>
</body>
</html>

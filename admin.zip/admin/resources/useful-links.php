<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Useful Links | SAU Admin</title>
    <link rel="stylesheet" href="../assets/dashboard.css">
</head>
<body>
    <main class="container">
        <p class="brand">SOUTH ASIAN UNIVERSITY · ADMIN</p>
        <a class="back" href="index.php">← Resources Dashboard</a>
        <h1>Useful Links</h1>
        <p class="intro">Resources / Useful Links</p>
        <div class="notice">Form preview: saving is not connected to a database yet. These fields do not update the public website.</div>
        <form class="editor">
            <label for="field-0">Link title</label>
            <input id="field-0" name="link-title" type="text">
            <label for="field-1">Link URL</label>
            <input id="field-1" name="link-url" type="text">
            <label for="field-2">Description</label>
            <textarea id="field-2" name="description" rows="5"></textarea>
            <div class="actions">
                <button type="button" disabled>Save Changes — database required</button>
                <a href="index.php">Back to sections</a>
            </div>
        </form>
    </main>
</body>
</html>

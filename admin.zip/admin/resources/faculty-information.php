<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Information | SAU Admin</title>
    <link rel="stylesheet" href="../assets/dashboard.css">
</head>
<body>
    <main class="container">
        <p class="brand">SOUTH ASIAN UNIVERSITY · ADMIN</p>
        <a class="back" href="index.php">← Resources Dashboard</a>
        <h1>Faculty Information</h1>
        <p class="intro">Resources / Faculty Information</p>
        <div class="notice">Form preview: saving is not connected to a database yet. These fields do not update the public website.</div>
        <form class="editor">
            <label for="field-0">Name</label>
            <input id="field-0" name="name" type="text">
            <label for="field-1">Position</label>
            <input id="field-1" name="position" type="text">
            <label for="field-2">Email</label>
            <input id="field-2" name="email" type="email">
            <label for="field-3">Image path</label>
            <input id="field-3" name="image-path" type="text">
            <label for="field-4">Profile URL</label>
            <input id="field-4" name="profile-url" type="text">
            <div class="actions">
                <button type="button" disabled>Save Changes — database required</button>
                <a href="index.php">Back to sections</a>
            </div>
        </form>
    </main>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | SAU Admin</title>
    <link rel="stylesheet" href="assets/dashboard.css">
</head>
<body>
    <main class="container">
        <p class="brand">SOUTH ASIAN UNIVERSITY · ADMIN</p>
        <h1>Welcome to Dashboard</h1>
        <p class="intro">Choose the website page you want to manage.</p>
        <div class="grid">
        <a class="dashboard-box red" href="home/index.php">
            <span class="icon" aria-hidden="true">⌂</span>
            <h2>Home</h2>
            <p>Manage the Home page</p>
            <span class="open">Open →</span>
        </a>
        <a class="dashboard-box blue" href="about/index.php">
            <span class="icon" aria-hidden="true">ⓘ</span>
            <h2>About</h2>
            <p>Manage the About page</p>
            <span class="open">Open →</span>
        </a>
        <a class="dashboard-box green" href="programmes/index.php">
            <span class="icon" aria-hidden="true">▤</span>
            <h2>Programmes</h2>
            <p>Manage academic programmes</p>
            <span class="open">Open →</span>
        </a>
        <a class="dashboard-box dark" href="research/index.php">
            <span class="icon" aria-hidden="true">⌕</span>
            <h2>Research</h2>
            <p>Manage research information</p>
            <span class="open">Open →</span>
        </a>
        <a class="dashboard-box purple" href="notices/index.php">
            <span class="icon" aria-hidden="true">◷</span>
            <h2>Notices</h2>
            <p>Manage departmental announcements</p>
            <span class="open">Open →</span>
        </a>
        <a class="dashboard-box orange" href="resources/index.php">
            <span class="icon" aria-hidden="true">▣</span>
            <h2>Resources</h2>
            <p>Manage department resources</p>
            <span class="open">Open →</span>
        </a>
        <a class="dashboard-box teal" href="contact/index.php">
            <span class="icon" aria-hidden="true">✉</span>
            <h2>Contact</h2>
            <p>Manage contact and footer information</p>
            <span class="open">Open →</span>
        </a>
        </div>
    </main>
</body>
</html>
